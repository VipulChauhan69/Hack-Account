
package personalscheduler;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;

import java.util.Scanner;

public class PersonalScheduler 
{
    int l, y, d, m;
        String dd, mm, yy;
        Scanner sc = new Scanner(System.in);
    
    public  void usingBufferedWritter() throws IOException 
    {
        
        System.out.println("Enter name of person to be met:");
        String name=sc.nextLine();
       
        
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        
 
        
        int maxdays[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
 
        
        String month[]={ "", "January", "February", "March", "April", "May", "June", "July", "August",
                         "September", "October", "November", "December" };
 
        System.out.print("Enter any date in 8 digits (ddmmyyyy) format: ");
        String date = br.readLine(); //inputting the date in String format
 
        l = date.length(); //finding number of digits in the given input
 
        if(l==8) //performing the task only when number of digits is 8
        {
            dd = date.substring(0,2); //extracting the day in String format
            mm = date.substring(2,4); 
            yy = date.substring(4); 
            d = Integer.parseInt(dd); //day in Integer format
            m = Integer.parseInt(mm); 
            y = Integer.parseInt(yy); 
 
            if((y%400==0) || ((y%100!=0)&&(y%4==0))) // condition for leap year
            {
                maxdays[2]=29;
            }
             
          
 
            if(m<0 || m>12 || d<0 || d>maxdays[m] || y<0 || y>9999) // Performing Date Validation
            {
            System.out.println("The day, month or year are outside acceptable limit");
            }
 
            else
            {
                /* First Part */
                System.out.println("Date in dd/mm/yyyy format = "+dd+"/"+mm+"/"+yy);
                              
                /* Second Part */
                System.out.print("Date in dd, month name, yyyy format = "+dd+" "+month[m]+", "+yy);
            }
        }
 
        else
            System.out.println("Wrong Input");

        BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\vipul\\data.txt"));
        writer.write("Person Scheduler\n");
        writer.write("Person name: "+name+"\n");
        writer.write("Date in dd/mm/yyyy format = "+dd+"/"+mm+"/"+yy);
        writer.close();
        
        StringBuilder sb = new StringBuilder();

        try (BufferedReader br1 = Files.newBufferedReader(Paths.get("C:\\vipul\\data.txt"))) {

            // read line by line
            String line;
            while ((line = br1.readLine()) != null) {
                sb.append(line).append("\n");
            }

        } catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        }
        System.out.println("\nDisplay details");
        System.out.println(sb);
        
    }
    public static void main(String[] args) throws IOException 
    {
        PersonalScheduler obj=new PersonalScheduler();
        obj.usingBufferedWritter();
    }
    
}
